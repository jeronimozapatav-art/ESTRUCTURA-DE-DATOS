package com.vibra.desktop;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class GestorUsuarios {

    // HashMap almacena usuarios usando su ID como clave.
    private final Map<Long, Usuario> mapaUsuarios = new HashMap<>();

    // Registrar un usuario.
    public void agregarUsuario(Usuario usuario) {

        if (usuario == null) {
            throw new IllegalArgumentException(
                "El usuario no puede ser nulo."
            );
        }

        mapaUsuarios.put(usuario.getId(), usuario);
    }

    // Buscar un usuario por ID: O(1) promedio.
    public Usuario buscarUsuario(long id) {
        return mapaUsuarios.get(id);
    }

    // Comprobar si existe un usuario.
    public boolean existeUsuario(long id) {
        return mapaUsuarios.containsKey(id);
    }

    // Eliminar un usuario.
    public void eliminarUsuario(long id) {
        mapaUsuarios.remove(id);
    }

    // Consultar los usuarios sin permitir modificar el mapa original.
    public Map<Long, Usuario> obtenerUsuarios() {
        return Collections.unmodifiableMap(
            new HashMap<>(mapaUsuarios)
        );
    }

    // Cantidad de usuarios registrados.
    public int cantidadUsuarios() {
        return mapaUsuarios.size();
    }
}