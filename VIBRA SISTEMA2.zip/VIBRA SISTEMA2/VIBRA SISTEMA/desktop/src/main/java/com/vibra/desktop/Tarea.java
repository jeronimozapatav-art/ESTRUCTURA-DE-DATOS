package com.vibra.desktop;

public class Tarea implements Comparable<Tarea> {

    private final int id;
    private final String descripcion;
    private boolean completada;
    private final int prioridad;

    // Constructor compatible con el código anterior
    public Tarea(int id, String descripcion) {
        this(id, descripcion, 2);
    }

    // Constructor con prioridad
    public Tarea(int id, String descripcion, int prioridad) {

        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "La descripción no puede estar vacía."
            );
        }

        if (prioridad < 1 || prioridad > 3) {
            throw new IllegalArgumentException(
                "La prioridad debe ser 1, 2 o 3."
            );
        }

        this.id = id;
        this.descripcion = descripcion.trim();
        this.prioridad = prioridad;
        this.completada = false;
    }

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public boolean isCompletada() {
        return completada;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public String getNombrePrioridad() {
        switch (prioridad) {
            case 3:
                return "ALTA";
            case 2:
                return "MEDIA";
            default:
                return "BAJA";
        }
    }

    public void completar() {
        this.completada = true;
    }

    // Ordena primero las tareas de mayor prioridad.
    @Override
    public int compareTo(Tarea otra) {

        int resultado = Integer.compare(
            otra.prioridad,
            this.prioridad
        );

        if (resultado == 0) {
            return Integer.compare(this.id, otra.id);
        }

        return resultado;
    }
}