
package com.vibra.desktop;

public class Usuario {

    private long id;
    private String username;
    private String displayName;

    public Usuario(long id, String username, String displayName) {
        this.id = id;
        this.username = username;
        this.displayName = displayName;
    }

    public long getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public String getDisplayName() {
        return displayName;
    }
    @Override
public String toString() {
    return displayName + " (@" + username + ")";
}
}

