
package com.vibra.desktop;

import java.util.*;

/**
 * Implementación de las estructuras de datos solicitadas en EA3.
 *
 * R1: HashMap de usuarios.
 * R2: Grafo no dirigido de amistades.
 * R3: Pila de publicaciones con ArrayDeque.
 * R4: Ordenamiento de tareas con Collections.sort().
 */
public class EstructurasEA3 {

    // R1: Usuarios identificados por su ID.
    private final HashMap<Long, Usuario> usuarios = new HashMap<>();

    // R2: Lista de adyacencia para representar amistades mutuas.
    private final HashMap<Long, ArrayList<Long>> grafo = new HashMap<>();

    // R3: Pila de publicaciones.
    private final ArrayDeque<Publicacion> feed = new ArrayDeque<>();

    // R4: Lista de tareas.
    private final ArrayList<Tarea> tareas = new ArrayList<>();

    // Representación de una publicación.
public static class Publicacion {
    private final long id;
    private final long autorId;
    private final String contenido;

    // Constructor original: se conserva para no afectar el código existente.
    public Publicacion(long autorId, String contenido) {
        this(-1, autorId, contenido);
    }

    // Constructor para publicaciones reales provenientes de la base de datos.
    public Publicacion(long id, long autorId, String contenido) {
        this.id = id;
        this.autorId = autorId;
        this.contenido = contenido;
    }

    public long getId() {
        return id;
    }

    public long getAutorId() {
        return autorId;
    }

    public String getContenido() {
        return contenido;
    }
}

    // =====================================================
    // R1: GESTIÓN DE USUARIOS CON HASHMAP
    // =====================================================

    public void agregarUsuario(Usuario usuario) {

        if (usuario == null) {
            throw new IllegalArgumentException(
                "El usuario no puede ser nulo."
            );
        }

        usuarios.put(usuario.getId(), usuario);

        grafo.putIfAbsent(
            usuario.getId(),
            new ArrayList<>()
        );
    }

    // Buscar usuario por ID. O(1) promedio.
    public Usuario buscarUsuario(long id) {
        return usuarios.get(id);
    }

    // Consultar todos los usuarios.
    public Map<Long, Usuario> obtenerUsuarios() {
        return Collections.unmodifiableMap(
            new HashMap<>(usuarios)
        );
    }

    // Eliminar usuario de las estructuras.
    public boolean eliminarUsuario(long id) {

        if (!usuarios.containsKey(id)) {
            return false;
        }

        usuarios.remove(id);

        // Eliminar sus amistades.
        ArrayList<Long> amigos = grafo.remove(id);

        if (amigos != null) {
            for (Long amigoId : amigos) {
                ArrayList<Long> listaAmigos = grafo.get(amigoId);

                if (listaAmigos != null) {
                    listaAmigos.remove(id);
                }
            }
        }

        return true;
    }

    // =====================================================
    // R2: GRAFO NO DIRIGIDO DE AMISTADES
    // =====================================================

    // Agregar amistad en ambos sentidos.
    public boolean agregarAmigo(long idA, long idB) {

        if (idA == idB) {
            return false;
        }

        if (!usuarios.containsKey(idA) ||
            !usuarios.containsKey(idB)) {
            return false;
        }

        grafo.putIfAbsent(idA, new ArrayList<>());
        grafo.putIfAbsent(idB, new ArrayList<>());

        if (!grafo.get(idA).contains(idB)) {
            grafo.get(idA).add(idB);
        }

        if (!grafo.get(idB).contains(idA)) {
            grafo.get(idB).add(idA);
        }

        return true;
    }

    // Eliminar amistad en ambos sentidos.
    public boolean eliminarAmigo(long idA, long idB) {

        if (!grafo.containsKey(idA) ||
            !grafo.containsKey(idB)) {
            return false;
        }

        boolean eliminadoA = grafo.get(idA).remove(idB);
        boolean eliminadoB = grafo.get(idB).remove(idA);

        return eliminadoA || eliminadoB;
    }

    // Consultar amigos de un usuario.
    public List<Long> obtenerAmigos(long id) {

        if (!grafo.containsKey(id)) {
            return Collections.emptyList();
        }

        return Collections.unmodifiableList(
            new ArrayList<>(grafo.get(id))
        );
    }

    // Comprobar si dos usuarios son amigos.
    public boolean sonAmigos(long idA, long idB) {

        return grafo.containsKey(idA)
            && grafo.get(idA).contains(idB);
    }

    // =====================================================
    // R3: PILA DE PUBLICACIONES CON ARRAYDEQUE
    // =====================================================

    // Agregar publicación de un usuario registrado.
    public void publicar(long autorId, String contenido) {

        if (!usuarios.containsKey(autorId)) {
            throw new IllegalArgumentException(
                "El autor no está registrado."
            );
        }

        if (contenido == null || contenido.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "El contenido no puede estar vacío."
            );
        }

        feed.push(
            new Publicacion(autorId, contenido.trim())
        );
    }

    // Cargar publicaciones existentes en la pila.
    // La lista debe llegar de la más antigua a la más reciente.
    public void cargarPublicaciones(List<Publicacion> publicaciones) {

        feed.clear();

        if (publicaciones == null) {
            return;
        }

        for (Publicacion publicacion : publicaciones) {

            if (publicacion != null) {
                feed.push(publicacion);
            }
        }
    }

    // Publicar contenido sin autor identificado.
    public void publicar(String contenido) {

        if (contenido == null || contenido.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "El contenido no puede estar vacío."
            );
        }

        feed.push(
            new Publicacion(-1, contenido.trim())
        );
    }

    // Consultar la publicación más reciente.
    public Publicacion ultimaPublicacion() {
        return feed.peek();
    }

    // Obtener las últimas cinco publicaciones de amigos.
    public List<Publicacion> obtenerUltimasCincoPublicacionesDeAmigos(
        long usuarioId
    ) {

        List<Publicacion> resultado = new ArrayList<>();

        List<Long> amigos = obtenerAmigos(usuarioId);

        for (Publicacion publicacion : feed) {

            if (amigos.contains(publicacion.getAutorId())) {
                resultado.add(publicacion);
            }

            if (resultado.size() == 5) {
                break;
            }
        }

        return Collections.unmodifiableList(resultado);
    }

    // Consultar cantidad de publicaciones.
    public int cantidadPublicaciones() {
        return feed.size();
    }

    // =====================================================
    // R4: TAREAS ORDENADAS POR PRIORIDAD
    // =====================================================

    // Agregar una tarea con prioridad.
    public void agregarTarea(
        int id,
        String descripcion,
        int prioridad
    ) {

        Tarea nueva = new Tarea(
            id,
            descripcion,
            prioridad
        );

        tareas.add(nueva);

        Collections.sort(tareas);
    }

    // Obtener tareas ordenadas por prioridad.
    public List<Tarea> obtenerTareas() {

        Collections.sort(tareas);

        return Collections.unmodifiableList(
            new ArrayList<>(tareas)
        );
    }

    // Completar una tarea.
    public boolean completarTarea(int id) {

        for (Tarea tarea : tareas) {

            if (tarea.getId() == id) {
                tarea.completar();
                return true;
            }
        }

        return false;
    }

    // Eliminar una tarea.
    public boolean eliminarTarea(int id) {

        return tareas.removeIf(
            tarea -> tarea.getId() == id
        );
    }

    // Consultar tareas pendientes.
    public List<Tarea> obtenerTareasPendientes() {

        List<Tarea> pendientes = new ArrayList<>();

        for (Tarea tarea : tareas) {

            if (!tarea.isCompletada()) {
                pendientes.add(tarea);
            }
        }

        Collections.sort(pendientes);

        return Collections.unmodifiableList(pendientes);
    }
}
