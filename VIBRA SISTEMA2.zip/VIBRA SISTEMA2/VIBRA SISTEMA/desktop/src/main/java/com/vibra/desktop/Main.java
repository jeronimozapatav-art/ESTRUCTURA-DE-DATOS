
package com.vibra.desktop;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.util.List;

public class Main extends JFrame {

    private final Color bg = new Color(13, 15, 22);
    private final Color panel = new Color(25, 28, 39);
    private final Color purple = new Color(139, 92, 246);
    private final Color white = new Color(242, 244, 250);
    private final Color muted = new Color(160, 166, 184);
    private final Color red = new Color(190, 55, 75);

    private final HttpClient http = HttpClient.newHttpClient();
    private final ObjectMapper json = new ObjectMapper();

    private final GestorTareas gestorTareas = new GestorTareas();
private final EstructurasEA3 estructurasEA3 = new EstructurasEA3();
private int siguienteIdTarea = 1;

    private String baseUrl = "http://localhost:8080";
    private String username;
    private String password;
    private String displayName;
    private long userId;

    private boolean perfilVisible = false;

    private JPanel page;

    public Main() {
        super("VIBRA | Comunidad digital");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1050, 820);
        setMinimumSize(new Dimension(760, 650));
        setLocationRelativeTo(null);
        getContentPane().setBackground(bg);
        showAuth();
    }

    // ---------------- INICIO DE SESIÓN ----------------

    private void showAuth() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(bg);

        JPanel card = card();
        card.setPreferredSize(new Dimension(430, 560));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));

        JLabel logo = label("V I B R A", 34, white, true);
        logo.setAlignmentX(CENTER_ALIGNMENT);

        JLabel sub = label(
            "Comparte momentos. Conecta personas.",
            14, muted, false
        );
        sub.setAlignmentX(CENTER_ALIGNMENT);

        JTextField server = field(baseUrl);
        JTextField user = field("");
        JPasswordField pass = new JPasswordField();
        styleField(pass);
        JTextField name = field("");

        JButton login = button("INICIAR SESIÓN");
        JButton register = button("CREAR CUENTA");

        card.add(Box.createVerticalStrut(25));
        card.add(logo);
        card.add(Box.createVerticalStrut(8));
        card.add(sub);
        card.add(Box.createVerticalStrut(28));

        addField(card, label("Dirección del servidor", 12, muted, true), server);
        addField(card, label("Usuario", 12, muted, true), user);
        addField(card, label("Contraseña", 12, muted, true), pass);
        addField(card, label("Nombre visible", 12, muted, true), name);

        card.add(Box.createVerticalStrut(18));
        card.add(login);
        card.add(Box.createVerticalStrut(10));
        card.add(register);

    login.addActionListener(e -> {
    baseUrl = server.getText().trim().replaceAll("/$", "");

    try {
        String enteredPassword = new String(pass.getPassword());

        Map<String, Object> result = postJson(
            "/api/login",
            Map.of(
                "username", user.getText().trim(),
                "password", enteredPassword
            ),
            false
        );

        username = user.getText().trim();
        password = enteredPassword;

        userId = obtenerId(result);

        displayName = obtenerTexto(
            result,
            "displayName",
            "display_name",
            "name"
        );

        if (displayName.isEmpty()) {
            displayName = username;
        }

        // Registrar el usuario en el HashMap de EA3.
        estructurasEA3.agregarUsuario(
            new Usuario(userId, username, displayName)
        );

        showApp();

    } catch (Exception ex) {
        error(ex);
    }
});

        register.addActionListener(e -> {
            baseUrl = server.getText().trim().replaceAll("/$", "");

            try {
                postJson(
                    "/api/register",
                    Map.of(
                        "username", user.getText().trim(),
                        "password", new String(pass.getPassword()),
                        "displayName", name.getText().trim()
                    ),
                    false
                );

                JOptionPane.showMessageDialog(
                    this,
                    "Cuenta creada. Ahora inicia sesión."
                );

            } catch (Exception ex) {
                error(ex);
            }
        });

        root.add(card);
        setContentPane(root);
        revalidate();
        repaint();
    }

    // ---------------- INTERFAZ PRINCIPAL ----------------

    private void showApp() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(bg);

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(panel);
        top.setBorder(new EmptyBorder(15, 22, 15, 22));

        top.add(label("VIBRA", 28, white, true), BorderLayout.WEST);
        top.add(label("Hola, " + displayName, 14, muted, false), BorderLayout.EAST);

        root.add(top, BorderLayout.NORTH);

        page = new JPanel(new BorderLayout());
        page.setBackground(bg);
        root.add(page, BorderLayout.CENTER);

        JPanel nav = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 12));
        nav.setBackground(panel);

        String[] tabs = {
            "INICIO",
            "EXPLORAR",
            "MI PERFIL",
            "TAREAS PENDIENTES"
        };

        for (String tab : tabs) {
            JButton b = button(tab);

            b.addActionListener(e -> {
                if (tab.equals("INICIO")) {
                    feedPage();
                } else if (tab.equals("EXPLORAR")) {
                    explorePage();
                } else if (tab.equals("MI PERFIL")) {
                    profilePage();
                } else if (tab.equals("TAREAS PENDIENTES")) {
                    tareasPage();
                }
            });

            nav.add(b);
        }

        root.add(nav, BorderLayout.SOUTH);
        setContentPane(root);

        feedPage();
        revalidate();
        repaint();
    }

    
// ---------------- PUBLICACIONES ----------------

private void feedPage() {
    perfilVisible = false;
    page.removeAll();

    JPanel wrap = new JPanel(new BorderLayout(0, 15));
    wrap.setBackground(bg);
    wrap.setBorder(new EmptyBorder(20, 22, 20, 22));

    JPanel compose = card();
    compose.setLayout(new BorderLayout(10, 10));

    JLabel title = label(
        "¿Qué quieres compartir hoy?",
        18, white, true
    );

    JTextArea caption = new JTextArea(3, 30);
    styleArea(caption);

    JButton choose = button("+ FOTO");
    JButton publish = button("PUBLICAR");

    JLabel chosen = label(
        "Ninguna imagen seleccionada",
        11, muted, false
    );

    final File[] photo = {null};

    choose.addActionListener(e -> {
        JFileChooser fc = new JFileChooser();

        if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            photo[0] = fc.getSelectedFile();
            chosen.setText(photo[0].getName());
        }
    });

    JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
    row.setOpaque(false);
    row.add(choose);
    row.add(chosen);
    row.add(publish);

    compose.add(title, BorderLayout.NORTH);
    compose.add(new JScrollPane(caption), BorderLayout.CENTER);
    compose.add(row, BorderLayout.SOUTH);

    publish.addActionListener(e -> {
        try {
            createPost(caption.getText(), photo[0]);

            caption.setText("");
            photo[0] = null;
            chosen.setText("Ninguna imagen seleccionada");

            feedPage();

        } catch (Exception ex) {
            error(ex);
        }
    });

    JPanel posts = new JPanel();
    posts.setBackground(bg);
    posts.setLayout(new BoxLayout(posts, BoxLayout.Y_AXIS));

    try {
        // 1. Cargar todos los usuarios en la estructura.
        List<Map<String, Object>> usuarios = getList("/api/users");

        for (Map<String, Object> usuario : usuarios) {
            long id = obtenerId(usuario);

            String username = obtenerTexto(usuario, "username");
            String displayName = obtenerTexto(usuario, "display_name");

            estructurasEA3.agregarUsuario(
                new Usuario(id, username, displayName)
            );
        }

        // 2. Cargar las amistades del usuario actual en el grafo.
        List<Long> amistades = getLongList("/api/friendships");

        for (Long amigoId : amistades) {
            estructurasEA3.agregarAmigo(userId, amigoId);
        }

        // 3. Obtener las publicaciones desde el backend.
        // El backend las entrega de la más antigua a la más reciente.
        List<Map<String, Object>> list = getList("/api/feed");

        System.out.println("Publicaciones recibidas: " + list.size());

        // 4. Conservar los datos completos de cada publicación.
        Map<Long, Map<String, Object>> postsPorId = new HashMap<>();

        List<EstructurasEA3.Publicacion> publicaciones =
            new ArrayList<>();

        for (Map<String, Object> p : list) {
            Long postId = obtenerIdOpcional(p, "id");
            Long autorId = obtenerIdOpcional(p, "user_id", "userId");

            if (postId != null && autorId != null) {
                publicaciones.add(
                    new EstructurasEA3.Publicacion(
                        postId,
                        autorId,
                        obtenerTexto(p, "caption")
                    )
                );

                postsPorId.put(postId, p);
            }
        }

        // 5. Cargar las publicaciones en la pila ArrayDeque.
        estructurasEA3.cargarPublicaciones(publicaciones);

        // 6. Obtener las últimas cinco publicaciones de amigos.
        List<EstructurasEA3.Publicacion> ultimas =
            estructurasEA3.obtenerUltimasCincoPublicacionesDeAmigos(
                userId
            );

        System.out.println(
            "Publicaciones de amigos mostradas: " + ultimas.size()
        );

        // 7. Mostrar las publicaciones conservando todos sus datos.
        if (ultimas.isEmpty()) {
            posts.add(label(
                "Todavía no hay publicaciones de tus amigos.",
                14, muted, false
            ));
        }

        for (EstructurasEA3.Publicacion publicacion : ultimas) {
            Map<String, Object> datos =
                postsPorId.get(publicacion.getId());

            if (datos != null) {
                posts.add(postCard(datos));
                posts.add(Box.createVerticalStrut(15));
            }
        }

    } catch (Exception ex) {
        posts.add(label(
            "No se pudo cargar el feed: " + ex.getMessage(),
            13, muted, false
        ));
        ex.printStackTrace();
    }

    JScrollPane sc = new JScrollPane(posts);
    sc.setBorder(null);
    sc.getViewport().setBackground(bg);
    sc.getVerticalScrollBar().setUnitIncrement(18);

    wrap.add(compose, BorderLayout.NORTH);
    wrap.add(sc, BorderLayout.CENTER);

    page.add(wrap);
    page.revalidate();
    page.repaint();
}


    // ---------------- TARJETA DE PUBLICACIÓN ----------------

    private JPanel postCard(Map<String, Object> p) {
        JPanel c = card();
        c.setLayout(new BoxLayout(c, BoxLayout.Y_AXIS));

        String who = obtenerTexto(
            p,
            "display_name",
            "displayName",
            "name"
        );

        String postUsername = obtenerTexto(p, "username");

        c.add(label(
            "@" + postUsername + "   ·   " + who,
            15, white, true
        ));

        Object image = p.get("image_name");

        if (image == null) {
            image = p.get("imageName");
        }

        if (image != null && !String.valueOf(image).trim().isEmpty()) {
            try {
                String imageName = String.valueOf(image);

                HttpResponse<byte[]> response = http.send(
                    authBuilder(
                        "/api/uploads/" + imageName
                    ).GET().build(),
                    HttpResponse.BodyHandlers.ofByteArray()
                );

                if (response.statusCode() >= 200 &&
                    response.statusCode() < 300) {

                    byte[] bytes = response.body();
                    ImageIcon icon = new ImageIcon(bytes);

                    Image scaled = icon.getImage().getScaledInstance(
                        650, 360, Image.SCALE_SMOOTH
                    );

                    JLabel pic = new JLabel(new ImageIcon(scaled));
                    pic.setAlignmentX(LEFT_ALIGNMENT);

                    c.add(Box.createVerticalStrut(10));
                    c.add(pic);

                } else {
                    c.add(label(
                        "[No se pudo cargar la fotografía]",
                        12, muted, false
                    ));
                }

            } catch (Exception ignored) {
                c.add(label(
                    "[No se pudo cargar la fotografía]",
                    12, muted, false
                ));
            }
        }

        String cap = obtenerTexto(p, "caption");

        JLabel txt = label(cap, 14, white, false);
        txt.setBorder(new EmptyBorder(10, 0, 8, 0));
        c.add(txt);

        Object likesValue = p.get("likes");
        Object commentsValue = p.get("comments");

        String likesText = likesValue == null
            ? "0"
            : String.valueOf(likesValue);

        String commentsText = commentsValue == null
            ? "0"
            : String.valueOf(commentsValue);

        JPanel actions = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 10, 0)
        );
        actions.setOpaque(false);

        JButton like = button(
            (Boolean.TRUE.equals(p.get("liked")) ? "♥  " : "♡  ")
            + likesText
        );

        JButton comment = button("COMENTAR · " + commentsText);
        JButton see = button("VER COMENTARIOS");

        actions.add(like);
        actions.add(comment);
        actions.add(see);

        long id = obtenerId(p);

        Long ownerId = obtenerIdOpcional(p, "user_id", "userId");

        if (ownerId != null && ownerId == userId) {
            JButton delete = button("ELIMINAR PUBLICACIÓN");
            delete.setBackground(red);
            actions.add(delete);

            delete.addActionListener(e -> deletePost(id));
        }

        c.add(actions);

        like.addActionListener(e -> {
            try {
                postJson(
                    "/api/posts/" + id + "/like",
                    Collections.emptyMap(),
                    true
                );

            refrescarPublicaciones();

            } catch (Exception ex) {
                error(ex);
            }
        });

        comment.addActionListener(e -> writeComment(id));
        see.addActionListener(e -> showComments(id));

        c.add(Box.createVerticalStrut(8));

        return c;
    }

    // ---------------- ELIMINAR PUBLICACIÓN PROPIA ----------------

    private void deletePost(long id) {

        int option = JOptionPane.showConfirmDialog(
            this,
            "¿Estás seguro de que deseas eliminar esta publicación?\n"
            + "También se eliminarán sus comentarios y likes.",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
        );

        if (option != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            String url = baseUrl + "/api/posts/" + id;

            HttpRequest request = authBuilder("/api/posts/" + id)
                .header("Accept", "application/json")
                .DELETE()
                .build();

            System.out.println("Método: " + request.method());
            System.out.println("Dirección: " + url);
            System.out.println("ID de publicación: " + id);

            HttpResponse<String> response = http.send(
                request,
                HttpResponse.BodyHandlers.ofString()
            );

            System.out.println("Código HTTP: " + response.statusCode());
            System.out.println("Respuesta: " + response.body());

            if (response.statusCode() < 200 ||
                response.statusCode() >= 300) {

                throw new IOException(
                    "Error HTTP " + response.statusCode()
                    + ": " + response.body()
                );
            }

            JOptionPane.showMessageDialog(
                this,
                "Publicación eliminada correctamente."
            );

            refrescarPublicaciones();

        } catch (Exception ex) {
            error(ex);
        }
    }

    // ---------------- COMENTARIOS ----------------

    private void writeComment(long id) {
        String body = JOptionPane.showInputDialog(
            this,
            "Escribe tu comentario:"
        );

        if (body == null || body.trim().isEmpty()) {
            return;
        }

        try {
            postJson(
                "/api/posts/" + id + "/comments",
                Map.of("body", body.trim()),
                true
            );

            refrescarPublicaciones();

        } catch (Exception ex) {
            error(ex);
        }
    }

private void refrescarPublicaciones() {
    if (perfilVisible) {
        profilePage();
    } else {
        feedPage();
    }
}

    private void showComments(long id) {
        try {
            List<Map<String, Object>> comments =
                getList("/api/posts/" + id + "/comments");

            StringBuilder s = new StringBuilder();

            for (Map<String, Object> c : comments) {
                s.append("@")
                    .append(obtenerTexto(c, "username"))
                    .append(": ")
                    .append(obtenerTexto(c, "body"))
                    .append("\n\n");
            }

            JTextArea area = new JTextArea(
                s.length() == 0
                    ? "Todavía no hay comentarios."
                    : s.toString(),
                12, 35
            );

            area.setEditable(false);
            area.setLineWrap(true);
            area.setWrapStyleWord(true);

            JOptionPane.showMessageDialog(
                this,
                new JScrollPane(area),
                "Comentarios",
                JOptionPane.PLAIN_MESSAGE
            );

        } catch (Exception ex) {
            error(ex);
        }
    }

    // ---------------- EXPLORAR PERSONAS ----------------

private void explorePage() {
    page.removeAll();
    page.setLayout(new BorderLayout(0, 12));

    // PANEL SUPERIOR: título y buscador siempre visibles
    JPanel encabezado = card();
    encabezado.setLayout(new BoxLayout(encabezado, BoxLayout.Y_AXIS));

    JLabel titulo = label(
        "Descubre personas",
        22, white, true
    );
    titulo.setAlignmentX(Component.LEFT_ALIGNMENT);

    JTextField buscador = field("");
    buscador.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
    buscador.setPreferredSize(new Dimension(400, 42));

    JPanel filaBusqueda = new JPanel(new BorderLayout(8, 0));
    filaBusqueda.setOpaque(false);
    filaBusqueda.add(
        label("BUSCAR:", 12, muted, true),
        BorderLayout.WEST
    );
    filaBusqueda.add(buscador, BorderLayout.CENTER);

    encabezado.add(titulo);
    encabezado.add(Box.createVerticalStrut(15));
    encabezado.add(filaBusqueda);

    page.add(encabezado, BorderLayout.NORTH);

    // PANEL DE RESULTADOS: solamente esta parte se desplaza
    JPanel resultados = new JPanel();
    resultados.setBackground(bg);
    resultados.setLayout(
        new BoxLayout(resultados, BoxLayout.Y_AXIS)
    );

    JScrollPane scroll = new JScrollPane(resultados);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(bg);
    scroll.getVerticalScrollBar().setUnitIncrement(18);

    page.add(scroll, BorderLayout.CENTER);

    try {
        // Cargar usuarios y personas que ya seguimos
        List<Map<String, Object>> usuarios =
            getList("/api/users");

        Set<Long> seguidos = new HashSet<>(
            getLongList("/api/following")
        );
        Set<Long> amigos = new HashSet<>(
    getLongList("/api/friendships")
);

// Cargar los usuarios en la estructura HashMap de EA3.
for (Map<String, Object> u : usuarios) {
    long id = obtenerId(u);

    String un = obtenerTexto(u, "username");

    String nombre = obtenerTexto(
        u,
        "display_name",
        "displayName",
        "name"
    );

    estructurasEA3.agregarUsuario(
        new Usuario(id, un, nombre)
    );
}

// Cargar las amistades del servidor en el grafo de EA3.
List<Long> amistades = getLongList("/api/friendships");

for (Long amigoId : amistades) {
    estructurasEA3.agregarAmigo(userId, amigoId);
}

       // Actualizar resultados según lo escrito
Runnable actualizarResultados = () -> {
    resultados.removeAll();

    String texto = buscador.getText()
        .trim()
        .toLowerCase(Locale.ROOT);

    int encontrados = 0;

    for (Map<String, Object> u : usuarios) {

        long id = obtenerId(u);

        // Buscar el usuario en el HashMap de EA3.
        Usuario usuarioEA3 = estructurasEA3.buscarUsuario(id);

        if (usuarioEA3 == null) {
            continue;
        }

        String un = usuarioEA3.getUsername();
        String nombre = usuarioEA3.getDisplayName();

        // No mostrar nuestra propia cuenta.
        if (un.equalsIgnoreCase(username)) {
            continue;
        }

                // Buscar por nombre o usuario
                String datosBusqueda =
                    (nombre + " " + un).toLowerCase(Locale.ROOT);

                if (!datosBusqueda.contains(texto)) {
                    continue;
                }

                encontrados++;

                                JPanel fila = new JPanel(new BorderLayout(8, 5));
                fila.setBackground(new Color(37, 41, 55));
                fila.setBorder(new EmptyBorder(6, 10, 6, 10));

                fila.setPreferredSize(new Dimension(700, 48));
                fila.setMinimumSize(new Dimension(200, 48));
                fila.setMaximumSize(
                    new Dimension(Integer.MAX_VALUE, 48)
                );
                fila.setAlignmentX(Component.LEFT_ALIGNMENT);

                JLabel persona = label(
                    nombre + "  @" + un,
                    14, white, true
                );

                JButton follow = button(
                    seguidos.contains(id)
                        ? "SIGUIENDO ✓"
                        : "SEGUIR"
                );
        JButton friendship = button(
    amigos.contains(id)
        ? "ELIMINAR AMIGO"
        : "AGREGAR AMIGO"
);

friendship.setFont(
    new Font("Segoe UI", Font.BOLD, 10)
);
friendship.setMargin(new Insets(5, 8, 5, 8));

friendship.addActionListener(e -> {
    try {
        if (amigos.contains(id)) {

            HttpRequest request = authBuilder(
                "/api/friendships/" + id
            ).DELETE().build();

            send(request);

            estructurasEA3.eliminarAmigo(userId, id);
            amigos.remove(id);

        } else {

            postJson(
                "/api/friendships/" + id,
                Collections.emptyMap(),
                true
            );

            estructurasEA3.agregarAmigo(userId, id);
            amigos.add(id);
        }

        friendship.setText(
            amigos.contains(id)
                ? "ELIMINAR AMIGO"
                : "AGREGAR AMIGO"
        );

    } catch (Exception ex) {
        error(ex);
    }
});

                follow.setFont(
                    new Font("Segoe UI", Font.BOLD, 10)
                );
                follow.setMargin(new Insets(5, 8, 5, 8));

                // Acción de seguir o dejar de seguir
                follow.addActionListener(e -> {
                    try {
                        if (seguidos.contains(id)) {

                            HttpRequest request = authBuilder(
                                "/api/follow/" + id
                            ).DELETE().build();

                            send(request);

                            seguidos.remove(id);

                        } else {

                            postJson(
                                "/api/follow/" + id,
                                Collections.emptyMap(),
                                true
                            );

                            seguidos.add(id);
                        }

                        // Actualizar el botón sin perder la búsqueda
                        follow.setText(
                            seguidos.contains(id)
                                ? "SIGUIENDO ✓"
                                : "SEGUIR"
                        );

                    } catch (Exception ex) {
                        error(ex);
                    }
                });

                JPanel acciones = new JPanel(
    new FlowLayout(FlowLayout.RIGHT, 5, 0)
);
acciones.setOpaque(false);

acciones.add(follow);
acciones.add(friendship);

fila.add(persona, BorderLayout.CENTER);
fila.add(acciones, BorderLayout.EAST);

                resultados.add(fila);
                resultados.add(Box.createVerticalStrut(10));
            }

            if (encontrados == 0) {
                JLabel vacio = label(
                    texto.isEmpty()
                        ? "Todavía no hay personas disponibles."
                        : "No se encontraron personas con esa búsqueda.",
                    14, muted, false
                );

                vacio.setBorder(
                    new EmptyBorder(20, 5, 20, 5)
                );

                resultados.add(vacio);
            }

            resultados.revalidate();
            resultados.repaint();
        };

        // Buscar automáticamente mientras escribimos
        buscador.getDocument().addDocumentListener(
            new javax.swing.event.DocumentListener() {

                @Override
                public void insertUpdate(
                    javax.swing.event.DocumentEvent e
                ) {
                    actualizarResultados.run();
                }

                @Override
                public void removeUpdate(
                    javax.swing.event.DocumentEvent e
                ) {
                    actualizarResultados.run();
                }

                @Override
                public void changedUpdate(
                    javax.swing.event.DocumentEvent e
                ) {
                    actualizarResultados.run();
                }
            }
        );

        // Mostrar todos los usuarios al entrar
        actualizarResultados.run();

    } catch (Exception ex) {
        resultados.add(label(
            "No se pudieron cargar las personas: "
                + ex.getMessage(),
            13, muted, false
        ));
    }

    page.revalidate();
    page.repaint();
}


    // ---------------- PERFIL ----------------

    private void profilePage() {
        perfilVisible = true;
    page.removeAll();
    page.setLayout(new BorderLayout());

    JPanel contenido = new JPanel();
    contenido.setBackground(bg);
    contenido.setLayout(new BoxLayout(contenido, BoxLayout.Y_AXIS));
    contenido.setBorder(new EmptyBorder(16, 20, 16, 20));

    try {
        HttpRequest request = authBuilder(
            "/api/users/" + userId + "/profile"
        ).GET().build();

        HttpResponse<String> response = http.send(
            request,
            HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() < 200 ||
            response.statusCode() >= 300) {
            throw new IOException(
                "Error al consultar el perfil: " + response.body()
            );
        }

        Map<String, Object> perfil = json.readValue(
            response.body(),
            new TypeReference<Map<String, Object>>() {}
        );

        JPanel encabezado = card();
        encabezado.setLayout(
            new BoxLayout(encabezado, BoxLayout.Y_AXIS)
        );

        encabezado.add(label("MI PERFIL", 22, white, true));
        encabezado.add(Box.createVerticalStrut(5));

        encabezado.add(label(
            displayName + "  @" + username,
            16, white, false
        ));

        encabezado.add(Box.createVerticalStrut(14));

        JPanel estadisticas = new JPanel(
            new GridLayout(1, 4, 8, 0)
        );
        estadisticas.setOpaque(false);

        estadisticas.add(statCard(
            "PUBLICACIONES", perfil.get("postsCount")
        ));

        estadisticas.add(statCard(
            "SEGUIDORES", perfil.get("followersCount")
        ));

        estadisticas.add(statCard(
            "SIGUIENDO", perfil.get("followingCount")
        ));

        estadisticas.add(statCard(
            "ME GUSTA", perfil.get("likesReceived")
        ));

        encabezado.add(estadisticas);

        contenido.add(encabezado);
        contenido.add(Box.createVerticalStrut(14));

        contenido.add(label(
            "MIS PUBLICACIONES", 18, white, true
        ));

        contenido.add(Box.createVerticalStrut(10));

        Object rawPosts = perfil.get("posts");

        List<Map<String, Object>> publicaciones =
            rawPosts == null
                ? Collections.emptyList()
                : json.convertValue(
                    rawPosts,
                    new TypeReference<List<Map<String, Object>>>() {}
                );

        if (publicaciones.isEmpty()) {
            contenido.add(label(
                "Todavía no has publicado nada.",
                14, muted, false
            ));
        } else {
            for (Map<String, Object> post : publicaciones) {
                contenido.add(postCard(post));
                contenido.add(Box.createVerticalStrut(12));
            }
        }

    } catch (Exception ex) {
        contenido.add(label(
            "No se pudo cargar tu perfil: " + ex.getMessage(),
            13, muted, false
        ));
    }

    JScrollPane scroll = new JScrollPane(contenido);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(bg);
    scroll.getVerticalScrollBar().setUnitIncrement(18);

    page.add(scroll, BorderLayout.CENTER);

    page.revalidate();
    page.repaint();
}


// ---------------- TAREAS PENDIENTES ----------------

private void tareasPage() {
    page.removeAll();
    page.setLayout(new BorderLayout());

    JPanel box = card();
    box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));

    box.add(label("TAREAS PENDIENTES", 22, white, true));
    box.add(Box.createVerticalStrut(15));

    JTextField descripcion = field("");
    String[] opcionesPrioridad = {"ALTA", "MEDIA", "BAJA"};
    JComboBox<String> prioridad = new JComboBox<>(opcionesPrioridad);
    prioridad.setBackground(new Color(37, 41, 55));
    prioridad.setForeground(white);
    prioridad.setMaximumSize(new Dimension(390, 40));
    prioridad.setAlignmentX(Component.LEFT_ALIGNMENT);

    JButton agregar = button("AGREGAR TAREA");

    box.add(label("Descripción de la tarea", 13, muted, true));
    box.add(Box.createVerticalStrut(5));
    box.add(descripcion);
    box.add(Box.createVerticalStrut(10));
    box.add(label("Prioridad", 13, muted, true));
    box.add(Box.createVerticalStrut(5));
    box.add(prioridad);
    box.add(Box.createVerticalStrut(10));
    box.add(agregar);
    box.add(Box.createVerticalStrut(20));

    agregar.addActionListener(e -> {
        try {
            String seleccion = (String) prioridad.getSelectedItem();
            int valorPrioridad;

            if ("ALTA".equals(seleccion)) {
                valorPrioridad = 3;
            } else if ("BAJA".equals(seleccion)) {
                valorPrioridad = 1;
            } else {
                valorPrioridad = 2;
            }

            estructurasEA3.agregarTarea(
                siguienteIdTarea++,
                descripcion.getText(),
                valorPrioridad
            );

            tareasPage();

        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(
                this,
                ex.getMessage(),
                "VIBRA",
                JOptionPane.WARNING_MESSAGE
            );
        }
    });

    List<Tarea> pendientes = estructurasEA3.obtenerTareasPendientes();

    if (pendientes.isEmpty()) {
        box.add(label(
            "No tienes tareas pendientes.",
            14, muted, false
        ));
    }

    for (Tarea tarea : pendientes) {
        JPanel fila = new JPanel(new BorderLayout(10, 5));
        fila.setBackground(new Color(37, 41, 55));
        fila.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel informacion = new JPanel();
        informacion.setOpaque(false);
        informacion.setLayout(
            new BoxLayout(informacion, BoxLayout.Y_AXIS)
        );

        informacion.add(label(
            tarea.getDescripcion(), 14, white, false
        ));
        informacion.add(Box.createVerticalStrut(5));
        informacion.add(label(
            "PRIORIDAD: " + tarea.getNombrePrioridad(),
            12, muted, true
        ));

        fila.add(informacion, BorderLayout.CENTER);

        JPanel acciones = new JPanel(
            new FlowLayout(FlowLayout.RIGHT)
        );
        acciones.setOpaque(false);

        JButton completar = button("COMPLETAR");
        JButton eliminar = button("ELIMINAR");
        eliminar.setBackground(red);

        completar.addActionListener(e -> {
            estructurasEA3.completarTarea(tarea.getId());
            tareasPage();
        });

        eliminar.addActionListener(e -> {
            estructurasEA3.eliminarTarea(tarea.getId());
            tareasPage();
        });

        acciones.add(completar);
        acciones.add(eliminar);
        fila.add(acciones, BorderLayout.SOUTH);

        box.add(fila);
        box.add(Box.createVerticalStrut(10));
    }

    JScrollPane scroll = new JScrollPane(box);
    scroll.setBorder(null);
    scroll.getViewport().setBackground(bg);
    scroll.getVerticalScrollBar().setUnitIncrement(18);

    page.add(scroll, BorderLayout.CENTER);
    page.revalidate();
    page.repaint();
}

private JPanel statCard(String titulo, Object valor) {
    JPanel estadistica = new JPanel();

    estadistica.setBackground(new Color(37, 41, 55));
    estadistica.setBorder(new EmptyBorder(10, 5, 10, 5));

    estadistica.setLayout(
        new BoxLayout(estadistica, BoxLayout.Y_AXIS)
    );

    JLabel numero = label(
        valor == null ? "0" : String.valueOf(valor),
        20, white, true
    );

    numero.setAlignmentX(Component.CENTER_ALIGNMENT);

    JLabel nombre = label(
        titulo, 10, muted, true
    );

    nombre.setAlignmentX(Component.CENTER_ALIGNMENT);

    estadistica.add(numero);
    estadistica.add(Box.createVerticalStrut(4));
    estadistica.add(nombre);

    return estadistica;
}
    // ---------------- CREAR PUBLICACIÓN ----------------

    private void createPost(String caption, File image) throws Exception {
        String boundary = "----VIBRA" + UUID.randomUUID();

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        write(
            out,
            "--" + boundary +
            "\r\nContent-Disposition: form-data; name=\"caption\"" +
            "\r\n\r\n" + caption + "\r\n"
        );

        if (image != null) {
            String type = Files.probeContentType(image.toPath());

            if (type == null || !type.startsWith("image/")) {
                throw new IOException(
                    "Selecciona un archivo de imagen."
                );
            }

            write(
                out,
                "--" + boundary +
                "\r\nContent-Disposition: form-data; name=\"image\"; filename=\"" +
                image.getName().replace("\"", "") +
                "\"\r\nContent-Type: " + type + "\r\n\r\n"
            );

            out.write(Files.readAllBytes(image.toPath()));
            write(out, "\r\n");
        }

        write(out, "--" + boundary + "--\r\n");

        HttpRequest req = authBuilder("/api/posts")
            .header(
                "Content-Type",
                "multipart/form-data; boundary=" + boundary
            )
            .POST(
                HttpRequest.BodyPublishers.ofByteArray(out.toByteArray())
            )
            .build();

        send(req);
    }

    // ---------------- CONEXIÓN CON EL SERVIDOR ----------------

    private List<Map<String, Object>> getList(String path)
            throws Exception {

        HttpResponse<String> r = send(
            authBuilder(path).GET().build()
        );

        return json.readValue(
            r.body(),
            new TypeReference<List<Map<String, Object>>>() {}
        );
    }

    private List<Long> getLongList(String path) throws Exception {
        HttpResponse<String> r = send(
            authBuilder(path).GET().build()
        );

        return json.readValue(
            r.body(),
            new TypeReference<List<Long>>() {}
        );
    }

    private HttpRequest.Builder authBuilder(String path) {
        HttpRequest.Builder b = HttpRequest.newBuilder(
            URI.create(baseUrl + path)
        );

        addAuth(b);
        return b;
    }

    private void addAuth(HttpRequest.Builder builder) {
        if (username != null && password != null) {
            builder.header("X-Username", username);
            builder.header("X-Password", password);
        }
    }

    private HttpResponse<String> send(HttpRequest request)
            throws Exception {

        HttpResponse<String> response = http.send(
            request,
            HttpResponse.BodyHandlers.ofString()
        );

        if (response.statusCode() < 200 ||
            response.statusCode() >= 300) {

            throw new IOException(
                "Error HTTP " + response.statusCode()
                + ": " + response.body()
            );
        }

        return response;
    }

    private Map<String, Object> postJson(
            String path,
            Map<String, ?> data,
            boolean authenticated
    ) throws Exception {

        HttpRequest.Builder builder = HttpRequest.newBuilder(
            URI.create(baseUrl + path)
        );

        builder.header("Content-Type", "application/json");
        builder.header("Accept", "application/json");

        if (authenticated) {
            addAuth(builder);
        }

        String body = json.writeValueAsString(data);

        HttpRequest request = builder
            .POST(HttpRequest.BodyPublishers.ofString(body))
            .build();

        HttpResponse<String> response = send(request);

        if (response.body() == null ||
            response.body().trim().isEmpty()) {
            return Collections.emptyMap();
        }

        return json.readValue(
            response.body(),
            new TypeReference<Map<String, Object>>() {}
        );
    }

    // ---------------- LECTURA SEGURA DE IDENTIFICADORES ----------------

    private long obtenerId(Map<String, Object> datos) {
        Long id = obtenerIdOpcional(
            datos,
            "id",
            "post_id",
            "postId",
            "user_id",
            "userId"
        );

        if (id == null) {
            throw new IllegalStateException(
                "El servidor no devolvió un identificador válido. Datos recibidos: "
                + datos
            );
        }

        return id;
    }

    private Long obtenerIdOpcional(
        Map<String, Object> datos,
        String... posiblesClaves
    ) {
        for (String clave : posiblesClaves) {
            Object valor = datos.get(clave);

            if (valor instanceof Number) {
                return ((Number) valor).longValue();
            }

            if (valor instanceof String) {
                try {
                    return Long.parseLong((String) valor);
                } catch (NumberFormatException ignored) {
                    // Se prueba con la siguiente clave.
                }
            }
        }

        return null;
    }

    // ---------------- LECTURA SEGURA DE TEXTOS ----------------

    private String obtenerTexto(
        Map<String, Object> datos,
        String... posiblesClaves
    ) {
        for (String clave : posiblesClaves) {
            Object valor = datos.get(clave);

            if (valor != null) {
                return String.valueOf(valor);
            }
        }

        return "";
    }

    // ---------------- ELEMENTOS VISUALES ----------------

    private void write(OutputStream o, String s) throws IOException {
        o.write(s.getBytes(StandardCharsets.UTF_8));
    }

    private JPanel card() {
        JPanel p = new JPanel();
        p.setBackground(panel);
        p.setBorder(new EmptyBorder(18, 18, 18, 18));
        return p;
    }

    private JLabel label(
        String s,
        int size,
        Color color,
        boolean bold
    ) {
        JLabel l = new JLabel(s);
        l.setForeground(color);
        l.setFont(
            new Font(
                "Segoe UI",
                bold ? Font.BOLD : Font.PLAIN,
                size
            )
        );

        return l;
    }

    private JTextField field(String s) {
        JTextField f = new JTextField(s);
        styleField(f);
        return f;
    }

    private void styleField(JTextField f) {
        f.setBackground(new Color(37, 41, 55));
        f.setForeground(white);
        f.setCaretColor(white);
        f.setBorder(new EmptyBorder(10, 12, 10, 12));
        f.setMaximumSize(new Dimension(390, 40));
    }

    private void styleArea(JTextArea a) {
        a.setBackground(new Color(37, 41, 55));
        a.setForeground(white);
        a.setCaretColor(white);
        a.setLineWrap(true);
        a.setWrapStyleWord(true);
        a.setBorder(new EmptyBorder(10, 10, 10, 10));
    }

    private JButton button(String s) {
        JButton b = new JButton(s);
        b.setBackground(purple);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(11, 16, 11, 16));
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));

        return b;
    }

    private void addField(
        JPanel p,
        JLabel l,
        JComponent c
    ) {
        l.setAlignmentX(LEFT_ALIGNMENT);
        c.setAlignmentX(LEFT_ALIGNMENT);

        p.add(l);
        p.add(Box.createVerticalStrut(4));
        p.add(c);
        p.add(Box.createVerticalStrut(12));
    }

private void error(Exception e) {

    e.printStackTrace();

    String detalle = e.getClass().getName()
        + "\n"
        + (e.getMessage() == null
            ? "La excepción no contiene un mensaje."
            : e.getMessage());

    JOptionPane.showMessageDialog(
        this,
        "No se pudo completar la operación.\n\n" + detalle,
        "VIBRA - Error",
        JOptionPane.ERROR_MESSAGE
    );
}

    // ---------------- EJECUTAR PROGRAMA ----------------

    public static void main(String[] args) {
        SwingUtilities.invokeLater(
            () -> new Main().setVisible(true)
        );
    }
}

