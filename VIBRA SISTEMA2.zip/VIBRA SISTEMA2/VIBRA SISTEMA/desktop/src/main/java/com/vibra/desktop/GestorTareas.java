
package com.vibra.desktop;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GestorTareas {

    private final List<Tarea> tareas = new ArrayList<>();
    private int siguienteId = 1;

    // Agregar tarea con prioridad media por defecto.
    // Conserva compatibilidad con el Main anterior.
    public void agregarTarea(String descripcion) {
        agregarTarea(descripcion, 2);
    }

    // Agregar tarea indicando su prioridad.
    public void agregarTarea(String descripcion, int prioridad) {

        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "La descripción no puede estar vacía."
            );
        }

        if (prioridad < 1 || prioridad > 3) {
            throw new IllegalArgumentException(
                "Selecciona una prioridad válida."
            );
        }

        Tarea nueva = new Tarea(
            siguienteId++,
            descripcion.trim(),
            prioridad
        );

        tareas.add(nueva);

        // Ordenar de mayor a menor prioridad.
        Collections.sort(tareas);
    }

    // Marcar una tarea como completada.
    public void completarTarea(int id) {

        for (Tarea tarea : tareas) {
            if (tarea.getId() == id) {
                tarea.completar();
                return;
            }
        }
    }

    // Eliminar una tarea.
    public void eliminarTarea(int id) {
        tareas.removeIf(tarea -> tarea.getId() == id);
    }

    // Obtener todas las tareas.
    public List<Tarea> obtenerTareas() {
        return new ArrayList<>(tareas);
    }

    // Obtener únicamente las pendientes y ordenarlas.
    public List<Tarea> obtenerPendientes() {

        List<Tarea> pendientes = new ArrayList<>();

        for (Tarea tarea : tareas) {
            if (!tarea.isCompletada()) {
                pendientes.add(tarea);
            }
        }

        Collections.sort(pendientes);

        return pendientes;
    }
}
