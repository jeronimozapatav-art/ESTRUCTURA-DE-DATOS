@echo off
cd /d "%~dp0"
java -cp "desktop\target\vibra-desktop-1.0.0.jar;desktop\target\lib\*" com.vibra.desktop.Main
pause
