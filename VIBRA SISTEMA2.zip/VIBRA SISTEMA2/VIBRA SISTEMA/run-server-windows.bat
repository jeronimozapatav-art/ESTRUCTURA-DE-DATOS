@echo off
cd /d "%~dp0server"
call mvn spring-boot:run
pause
