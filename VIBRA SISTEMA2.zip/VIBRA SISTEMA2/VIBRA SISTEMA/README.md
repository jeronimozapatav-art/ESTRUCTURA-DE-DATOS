# VIBRA 2.0 — red social Java de escritorio + servidor

## Qué incluye

- Registro e inicio de sesión; contraseñas almacenadas con BCrypt.
- Feed de publicaciones de cuentas propias y seguidas.
- Publicar texto y fotografías (máximo 8 MB por imagen).
- Seguir cuentas, dar/quitar me gusta y comentar.
- Persistencia central: base H2 en el servidor y fotografías en `uploads/`.
- Dos clientes Swing pueden conectarse al mismo servidor desde ubicaciones diferentes.

## Requisitos

- JDK 17 o superior.
- Maven 3.9 o superior.
- Internet para descargar dependencias y para que ambos computadores lleguen al servidor.

## 1. Construir el proyecto

Desde la carpeta raíz `VIBRA2`:

```bash
mvn clean package
```

## 2. Ejecutar el servidor localmente para probar

En una terminal:

```bash
cd server
mvn spring-boot:run
```

El servidor escucha en `http://localhost:8080`. Crea automáticamente `server/data/vibra.mv.db` y `server/uploads/`.

## 3. Ejecutar la aplicación de escritorio

En otra terminal, desde la raíz:

```bash
java -cp "desktop/target/vibra-desktop-1.0.0.jar;desktop/target/lib/*" com.vibra.desktop.Main
```

En Linux/macOS cambia `;` por `:`. En la pantalla de acceso escribe `http://localhost:8080` como servidor.

## 4. Conectar dos computadores desde lugares diferentes

El servidor debe estar publicado en un servicio de hosting accesible por HTTPS. **No basta con copiar el proyecto al otro computador.** Ambos deben escribir exactamente la misma URL pública en el campo “Dirección del servidor”.

Pasos generales de despliegue:

1. Publica este proyecto en un repositorio Git privado.
2. Crea un servicio Java/Maven en un proveedor de hosting que permita ejecutar Spring Boot.
3. Comando de construcción: `mvn -pl server -am clean package`.
4. Comando de inicio: `java -jar server/target/vibra-server-1.0.0.jar`.
5. Configura almacenamiento persistente para la carpeta de base de datos y para `uploads/`. Define `VIBRA_UPLOAD_DIR` con una ruta persistente y `JDBC_DATABASE_URL` con una ruta H2 dentro del volumen persistente, por ejemplo `jdbc:h2:file:/var/data/vibra;AUTO_SERVER=TRUE`.
6. Activa HTTPS y copia la URL pública asignada por el proveedor.
7. En ambos computadores abre VIBRA y pega esa misma URL.

**Importante:** si el hosting elimina el disco al reiniciar o desplegar, se pueden perder los datos. Debes confirmar que el plan elegido ofrece disco/volumen persistente. Para un proyecto real conviene una base PostgreSQL administrada y almacenamiento de imágenes dedicado.

## 5. Requisitos de la actividad académica

- R1 Usuarios: `HashMap` debe demostrarse en el modelo Java de la entrega académica; el servidor usa una base de datos relacional para persistencia.
- R2 Amistades/seguidores: relación de seguimiento almacenada en tabla `follows`.
- R3 Feed: consulta ordenada por fecha descendente; para demostrar formalmente el TDA Pila, incorpora `ArrayDeque` en una clase de demostración del proyecto académico.
- R4 Tareas: la actividad de tareas se puede implementar como módulo separado con `Collections.sort()`.

Este proyecto cubre el prototipo social solicitado, pero el informe de EA3 debe explicar también las estructuras exigidas por el enunciado. No presentes la base de datos como si fuera un `HashMap` o una pila.

## Seguridad y límites del prototipo

- Usa HTTPS en el servidor publicado.
- No uses una contraseña personal/repetida; crea una contraseña exclusiva para la demo.
- El prototipo usa encabezados de usuario/contraseña para simplificar la práctica. Antes de publicar una red para usuarios reales, cambia a sesiones/tokens, agrega límites de intentos, validación adicional, moderación y políticas de privacidad.
- No subas fotos privadas ni imágenes de otras personas sin permiso.

## Estructuras EA3 incluidas

La clase `desktop/src/main/java/com/vibra/desktop/EstructurasEA3.java` muestra explícitamente:

- R1 `HashMap<Integer, Usuario>` para buscar por ID en O(1) promedio.
- R2 `HashMap<Integer, ArrayList<Integer>>` y conexión mutua en ambas direcciones.
- R3 `ArrayDeque` con `push`/`peek` para el comportamiento LIFO.
- R4 `Collections.sort()` con prioridad descendente.
